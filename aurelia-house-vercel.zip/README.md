# Aurelia House — Hotel Website

A responsive React + Vite hotel concept website, built without Lovable.

## Run locally
1. Install Node.js (LTS).
2. Extract this folder.
3. Open a terminal in the project folder.
4. Run `npm install`
5. Run `npm run dev`

## Build for Vercel
1. Push the project folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Framework preset: **Vite** (usually detected automatically).
4. Build command: `npm run build`
5. Output directory: `dist`
6. Click **Deploy**.

## Before using this as a real hotel website
- Replace the fictional hotel name, rates, location, email and phone number.
- Replace any photography with licensed images of the actual property.
- The reservation form is a front-end demo only. Connect a booking engine, email service, or backend to receive real requests.
- Room prices and descriptions are illustrative.
