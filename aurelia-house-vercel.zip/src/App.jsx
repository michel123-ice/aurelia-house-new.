import React, { useState } from 'react';

const rooms = [
  {
    name: 'The Garden Suite',
    detail: 'A private sanctuary framed by soft morning light and lush garden views.',
    price: '₦285,000',
    size: '48 m²',
    image: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1200&q=85'
  },
  {
    name: 'The Signature Room',
    detail: 'Thoughtful textures, generous space and every detail considered.',
    price: '₦195,000',
    size: '36 m²',
    image: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1200&q=85'
  },
  {
    name: 'The Aurelia Residence',
    detail: 'An expansive retreat designed for longer stays and slower days.',
    price: '₦420,000',
    size: '72 m²',
    image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=85'
  }
];

const experiences = [
  ['01', 'A table worth gathering around', 'Seasonal menus, thoughtful ingredients and unhurried evenings.', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1000&q=85'],
  ['02', 'Space to slow down', 'Restore your rhythm with a considered wellness experience.', 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1000&q=85'],
  ['03', 'The city, at your pace', 'Discover the neighbourhood with recommendations from our team.', 'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=1000&q=85']
];

function Icon({ name }) {
  const common = { width: 18, height: 18, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true };
  if (name === 'arrow') return <svg {...common}><path d="M4 12h15M13 5l7 7-7 7"/></svg>;
  if (name === 'menu') return <svg {...common}><path d="M3 7h18M3 17h18"/></svg>;
  if (name === 'close') return <svg {...common}><path d="m6 6 12 12M18 6 6 18"/></svg>;
  return <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>;
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', arrival: '', departure: '', guests: '2 guests' });

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="announcement">A QUIETER KIND OF LUXURY <span>—</span> YOUR PLACE TO PAUSE</div>
      <header className="header">
        <a className="brand" href="#home" onClick={closeMenu} aria-label="Aurelia House home">
          <span className="brand-mark">A</span>
          <span className="brand-name">AURELIA <i>HOUSE</i></span>
        </a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          <Icon name={menuOpen ? 'close' : 'menu'} />
        </button>
        <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
          <a href="#stay" onClick={closeMenu}>The stay</a>
          <a href="#experience" onClick={closeMenu}>Experiences</a>
          <a href="#story" onClick={closeMenu}>Our story</a>
          <a href="#contact" onClick={closeMenu}>Contact</a>
          <a className="nav-book" href="#reserve" onClick={closeMenu}>Reserve a stay <Icon name="arrow" /></a>
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <img className="hero-image" src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=2200&q=90" alt="Elegant luxury hotel pool surrounded by tropical greenery" onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=2200&q=90'; }} />
          <div className="hero-shade" />
          <div className="hero-content">
            <p className="eyebrow light">A PLACE TO ARRIVE. A SPACE TO EXHALE.</p>
            <h1>Make room<br /><em>for stillness.</em></h1>
            <p className="hero-copy">An intimate hotel shaped around the art of feeling at home, wherever you find yourself.</p>
            <a className="button button-light" href="#stay">Discover the stay <Icon name="arrow" /></a>
          </div>
          <div className="hero-caption"><span>01 / 03</span><span>THE ART OF A CONSIDERED STAY</span><span>LAGOS · NIGERIA</span></div>
        </section>

        <section className="intro section-pad" id="story">
          <div className="intro-label"><span className="line" /> A DIFFERENT PERSPECTIVE ON HOSPITALITY</div>
          <div className="intro-main">
            <h2>Some places stay<br />with you <em>long after.</em></h2>
            <div className="intro-text">
              <p>Aurelia House is an invitation to experience the city differently. A place where considered design, genuine warmth and the freedom to slow down come together.</p>
              <a className="text-link" href="#experience">The Aurelia feeling <Icon name="arrow" /></a>
            </div>
          </div>
          <div className="intro-image-wrap">
            <img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1800&q=85" alt="Warm, thoughtfully designed hotel lounge" />
            <span className="image-note">THE BEAUTY OF TAKING YOUR TIME</span>
          </div>
        </section>

        <section className="rooms section-pad" id="stay">
          <div className="section-heading">
            <div><p className="eyebrow">YOUR OWN PRIVATE RETREAT</p><h2>Stay a little <em>longer.</em></h2></div>
            <p>Every room has its own character. All share the same promise: space to settle in, switch off and feel entirely at ease.</p>
          </div>
          <div className="room-grid">
            {rooms.map((room, index) => (
              <article className="room-card" key={room.name}>
                <div className="room-image">
                  <img src={room.image} alt={room.name} loading="lazy" />
                  <span className="room-number">0{index + 1}</span>
                </div>
                <div className="room-info">
                  <div><h3>{room.name}</h3><p>{room.detail}</p></div>
                  <div className="room-meta"><span>{room.size}</span><span>FROM {room.price} / NIGHT</span></div>
                </div>
              </article>
            ))}
          </div>
          <div className="center-action"><a className="button button-dark" href="#reserve">Explore your stay <Icon name="arrow" /></a></div>
          <p className="price-note">Illustrative room categories and rates. Confirm actual availability and pricing with the hotel.</p>
        </section>

        <section className="quote-band">
          <div className="quote-mark">“</div>
          <blockquote>Luxury is not about more.<br /><em>It is about what matters.</em></blockquote>
          <p>THE AURELIA HOUSE PHILOSOPHY</p>
        </section>

        <section className="experiences section-pad" id="experience">
          <div className="section-heading">
            <div><p className="eyebrow">MAKE THE MOST OF EVERY MOMENT</p><h2>Beyond the <em>ordinary.</em></h2></div>
            <p>Whether you seek a little adventure or a slower kind of day, find your own way to experience Aurelia.</p>
          </div>
          <div className="experience-grid">
            {experiences.map(([num, title, desc, image]) => (
              <article className="experience-card" key={num}>
                <div className="experience-image"><img src={image} alt="" loading="lazy" /></div>
                <div className="experience-copy"><span>{num}</span><div><h3>{title}</h3><p>{desc}</p></div><Icon name="arrow" /></div>
              </article>
            ))}
          </div>
        </section>

        <section className="reserve-section" id="reserve">
          <div className="reserve-image">
            <img src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1400&q=85" alt="A serene hotel swimming pool" loading="lazy" />
            <div className="reserve-image-caption">YOUR NEXT CHAPTER STARTS HERE</div>
          </div>
          <div className="reserve-panel">
            <p className="eyebrow">WE LOOK FORWARD TO WELCOMING YOU</p>
            <h2>Let's make<br /><em>your stay</em><br />happen.</h2>
            <p className="reserve-desc">Tell us a little about your plans. Our reservations team will be in touch to help you shape a stay worth looking forward to.</p>
            {submitted ? (
              <div className="success-message">
                <span className="success-icon">✓</span>
                <h3>Thank you, {form.name || 'there'}.</h3>
                <p>Your request has been prepared in this demo. Connect a booking service or email backend to receive real enquiries.</p>
                <button className="text-link" onClick={() => setSubmitted(false)}>Send another request <Icon name="arrow" /></button>
              </div>
            ) : (
              <form className="booking-form" onSubmit={submit}>
                <label>Your name<input required name="name" value={form.name} onChange={update} placeholder="Full name" /></label>
                <label>Email address<input required type="email" name="email" value={form.email} onChange={update} placeholder="you@example.com" /></label>
                <div className="form-row">
                  <label>Arrival<input required type="date" name="arrival" value={form.arrival} onChange={update} /></label>
                  <label>Departure<input required type="date" name="departure" value={form.departure} onChange={update} /></label>
                </div>
                <label>Guests<select name="guests" value={form.guests} onChange={update}><option>1 guest</option><option>2 guests</option><option>3 guests</option><option>4 guests</option><option>5+ guests</option></select></label>
                <button className="button button-dark submit-button" type="submit">Request a reservation <Icon name="arrow" /></button>
                <p className="form-disclaimer">Demo enquiry form — no reservation is created or sent yet.</p>
              </form>
            )}
          </div>
        </section>

        <section className="contact-strip section-pad" id="contact">
          <div><p className="eyebrow">FIND YOUR WAY TO US</p><h2>Close to everything.<br /><em>A world of your own.</em></h2></div>
          <div className="contact-details"><p>VICTORIA ISLAND, LAGOS<br />NIGERIA</p><p><a href="mailto:hello@aureliahouse.example">HELLO@AURELIAHOUSE.EXAMPLE</a><br />+234 (0) 000 000 0000</p><span>Address and contact details are placeholders for this concept website.</span></div>
        </section>
      </main>

      <footer className="footer">
        <a className="brand footer-brand" href="#home"><span className="brand-mark">A</span><span className="brand-name">AURELIA <i>HOUSE</i></span></a>
        <p>THE ART OF A CONSIDERED STAY.</p>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} AURELIA HOUSE</span><span>MADE FOR SLOWER MOMENTS</span><a href="#home">BACK TO TOP ↑</a></div>
      </footer>
    </div>
  );
}

export default App;
